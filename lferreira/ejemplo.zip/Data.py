import numpy as np
import pandas as pd
import altair as alt
import streamlit as st
import datetime
import calendar


def get_CasosTotales():
    URL = "https://raw.githubusercontent.com/MinCiencia/Datos-COVID19/master/output/producto3/CasosTotalesCumulativo_T.csv"
    df = pd.read_csv(URL)
    df = df.rename(columns={"Region": "fecha"})
    return df


def get_MuertosTotales():
    URL = "https://raw.githubusercontent.com/MinCiencia/Datos-COVID19/master/output/producto14/FallecidosCumulativo.csv"
    df  = pd.read_csv(URL)
    return df